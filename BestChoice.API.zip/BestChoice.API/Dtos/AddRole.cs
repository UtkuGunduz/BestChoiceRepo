﻿namespace BestChoice.API.Models
{
    public class AddRole
    {
        public string UserId { get; set; }
        public string RoleName { get; set; }
    }
}
