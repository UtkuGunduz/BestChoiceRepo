﻿namespace BestChoice.API.Models
{
    public class VisualDto
    {
        public int Id { get; set; }
        public string? PhotoUrl { get; set; }
        public string? VideoUrl { get; set; }
    }
}
