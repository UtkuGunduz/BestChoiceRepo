﻿using BestChoice.API.Models;

namespace BestChoice.API.Dtos
{
    public class ProductDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? Description { get; set; }
        public decimal? Price { get; set; }
        public decimal? Rating { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Updated { get; set; }
        public string? AdditionalFeatures { get; set; }
        public bool? IsActive { get; set; }
        public string? ReturnPolicy { get; set; }


        public string? BrandName { get; set; }
        public string? CategoryName { get; set; }
        public decimal? DiscountAmount { get; set; }
        public string? DiscountName { get; set; }
        public DateTime? DiscountStartDate { get; set; }
        public DateTime? DiscountEndDate { get; set; }
        public string? StockStatus { get; set; }
        public int? StockQuantity { get; set; }
        public List<ReviewDto>? Reviews { get; set; }
        public List<VisualDto>? Visuals { get; set; }
    }
}
