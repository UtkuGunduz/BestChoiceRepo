﻿namespace BestChoice.API.Dtos
{
    public class ResultDto
    {
        public bool Status { get; set; }
        public string Message { get; set; }

    }
}
