﻿using Microsoft.AspNetCore.Identity;

namespace BestChoice.API.Models
{
    public class AppRole : IdentityRole
    {
    }
}
