﻿using Microsoft.AspNetCore.Identity;

namespace BestChoice.API.Models
{
    public class AppUser : IdentityUser
    {
        public string FullName { get; set; }
        public string PicUrl { get; set; }
        public List<Review> Reviews { get; set; }
    }
}
