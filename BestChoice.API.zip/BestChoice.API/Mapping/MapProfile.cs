﻿using AutoMapper;
using BestChoice.API.Dtos;
using BestChoice.API.Models;
using System.Data;


namespace BestChoice.API.Mapping
{
    public class MapProfile : Profile
    {
        public MapProfile()
        {
            CreateMap<Product, ProductDto>().ReverseMap();
            CreateMap<Category, CategoryDto>().ReverseMap();
            CreateMap<CartItem, CartItemDto>().ReverseMap();
            CreateMap<WishlistItem, WishlistItemDto>().ReverseMap();
            CreateMap<Coupon, CouponDto>().ReverseMap();
            CreateMap<AppUser, LoginDto>().ReverseMap();
            CreateMap<AppUser, ChangePasswordDto>().ReverseMap();
            CreateMap<AppUser, UserDto>().ReverseMap(); ;
            CreateMap<Brand, BrandDto>().ReverseMap();
            CreateMap<Stock, StockDto>().ReverseMap();
            CreateMap<Discount, DiscountDto>().ReverseMap();
            CreateMap<Order, OrderDto>().ReverseMap();
        }

    }
}
