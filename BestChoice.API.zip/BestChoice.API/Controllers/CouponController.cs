﻿using AutoMapper;
using BestChoice.API.Dtos;
using BestChoice.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using static Azure.Core.HttpHeader;

namespace BestChoice.API.Controllers
{
    [Route("api/Coupons")]
    [ApiController]
    public class CouponController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;
        ResultDto result = new ResultDto();

        public CouponController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet("GetCoupons")]
        [Authorize(Roles = "Admin")]
        public List<CouponDto> GetCoupons()
        {
            var coupons = _context.Coupons.ToList();
            var couponDtos = _mapper.Map<List<CouponDto>>(coupons);
            return couponDtos;
        }

        [HttpPost("AddCoupon")]
        [Authorize(Roles = "Admin")]
        public ResultDto AddCoupon(string code, double discountPercentage, DateTime expirationDate)
        {
            if (_context.Coupons.Any(c => c.Code == code))
            {
                result.Status = false;
                result.Message = "Bu kupon kodu zaten var!";
                return result;
            }

            if (expirationDate <= DateTime.Now)
            {
                result.Status = false;
                result.Message = "Geçersiz son kullanma tarihi!";
                return result;
            }

            var coupon = new Coupon
            {
                Code = code,
                DiscountPercentage = discountPercentage,
                ExpiryDate = expirationDate,
                IsValid = true
            };

            _context.Coupons.Add(coupon);
            _context.SaveChanges();

            result.Status = true;
            result.Message = "Kupon Eklendi";

            return result;
        }

        [HttpPut("UpdateCoupon/{id}")]
        [Authorize(Roles = "Admin")]
        public ResultDto UpdateCoupon(int id, CouponDto dto)
        {
            var coupon = _context.Coupons.SingleOrDefault(c => c.Id == id);
            if (coupon == null)
            {
                result.Status = false;
                result.Message = "Kupon Bulunamadı!";
                return result;
            }

            coupon.Code = dto.Code;
            coupon.DiscountPercentage = dto.DiscountPercentage;
            coupon.ExpiryDate = dto.ExpiryDate;

            _context.Coupons.Update(coupon);
            _context.SaveChanges();

            result.Status = true;
            result.Message = "Kupon Düzenlendi";
            return result;
        }

        [HttpDelete("DeleteCoupon/{id}")]
        [Authorize(Roles = "Admin")]
        public ResultDto DeleteCoupon(int id)
        {

            var coupon = _context.Coupons.SingleOrDefault(c => c.Id == id);
            if (coupon == null)
            {
                result.Status = false;
                result.Message = "Kupon bulunamadı!";
                return result;
            }

            _context.Coupons.Remove(coupon);
            _context.SaveChanges();

            result.Status = true;
            result.Message = "Kupon silindi";
            return result;
        }
    }
}
