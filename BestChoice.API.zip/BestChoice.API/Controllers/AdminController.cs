﻿using BestChoice.API.Models;
using BestChoice.API.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace BestChoice.API.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/Admin")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly RoleManager<AppRole> _roleManager;
        private readonly AppDbContext _context;

        public AdminController(AppDbContext appDbContext, UserManager<AppUser> userManager, RoleManager<AppRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _context = appDbContext;
        }

        [HttpGet]
        [Route("Index")]
        public IActionResult Index()
        {
            int totalMemberCount = _userManager.Users.Count();
            int estateCount = _context.Products.Count();
            int nonAdminMemberCount = _roleManager.Roles.Count(m => m.Name == "Üye");
            int adminMemberCount = _roleManager.Roles.Count(m => m.Name == "Admin");

            var result = new
            {
                TotalMemberCount = totalMemberCount,
                EstateCount = estateCount,
                NonAdminMemberCount = nonAdminMemberCount,
                AdminMemberCount = adminMemberCount
            };

            return Ok(result);
        }

        [HttpGet]
        [Route("CheckAdmin")]
        public async Task<IActionResult> CheckAdmin()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return Unauthorized();
            }

            var isAdmin = await _userManager.IsInRoleAsync(user, "Admin");

            return Ok(new { IsAdmin = isAdmin });
        }

        [HttpGet]
        [Route("Members")]
        public async Task<IActionResult> Members()
        {
            var users = await _userManager.Users.ToListAsync();
            var userDtos = users.Select(user => new UserDto
            {
                Id = user.Id,
                FullName = user.FullName,
                Email = user.Email,
                UserName = user.UserName,
                Role = _userManager.GetRolesAsync(user).Result.FirstOrDefault()
            }).ToList();

            return Ok(userDtos);
        }

        [HttpGet]
        [Route("Roles")]
        public async Task<IActionResult> Roles()
        {
            var roles = await _roleManager.Roles.ToListAsync();
            return Ok(roles);
        }

        [HttpPost]
        [Route("RoleAdd")]
        public async Task<IActionResult> RoleAdd(AppRole model)
        {
            var role = await _roleManager.FindByNameAsync(model.Name);
            if (role == null)
            {
                var newRole = new AppRole { Name = model.Name };
                var result = await _roleManager.CreateAsync(newRole);

                if (result.Succeeded)
                {
                    return Ok(new { Message = "Rol başarıyla eklendi." });
                }

                return BadRequest(new { Errors = result.Errors });
            }

            return BadRequest(new { Message = "Bu isimde bir rol zaten mevcut." });
        }

        [HttpGet]
        [Route("GetCategories")]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _context.Categories.ToListAsync();
            return Ok(categories);
        }

        [HttpGet]
        [Route("CategoryListAjax")]
        public IActionResult CategoryListAjax()
        {
            var categories = _context.Categories.Select(x => new CategoryDto
            {
                Id = x.Id,
                Name = x.Name
            }).ToList();

            return Ok(categories);
        }

        [HttpGet]
        [Route("CategoryByIdAjax/{id}")]
        public IActionResult CategoryByIdAjax(int id)
        {
            var category = _context.Categories.Where(s => s.Id == id).Select(x => new CategoryDto
            {
                Id = x.Id,
                Name = x.Name
            }).SingleOrDefault();

            if (category == null)
            {
                return NotFound();
            }

            return Ok(category);
        }

        [HttpPost]
        [Route("CategoryAddEditAjax")]
        public async Task<IActionResult> CategoryAddEditAjax(CategoryDto model)
        {
            var categoryResult = new ResultDto();

            if (model.Id == 0)
            {
                var category = new Category { Name = model.Name };
                _context.Categories.Add(category);
                await _context.SaveChangesAsync();
                categoryResult.Message = "Kategori Eklendi";
            }
            else
            {
                var category = await _context.Categories.FirstOrDefaultAsync(x => x.Id == model.Id);
                if (category == null)
                {
                    return NotFound();
                }

                category.Name = model.Name;
                await _context.SaveChangesAsync();
                categoryResult.Message = "Kategori Güncellendi";
            }

            return Ok(categoryResult);
        }

        [HttpDelete]
        [Route("CategoryRemoveAjax/{id}")]
        public async Task<IActionResult> CategoryRemoveAjax(int id)
        {
            var category = await _context.Categories.FirstOrDefaultAsync(x => x.Id == id);
            if (category == null)
            {
                return NotFound();
            }

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            var categoryResult = new ResultDto { Message = "Kategori Silindi" };
            return Ok(categoryResult);
        }
    }
}
