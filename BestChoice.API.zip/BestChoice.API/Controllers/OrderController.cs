﻿using AutoMapper;
using BestChoice.API.Dtos;
using BestChoice.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace BestChoice.API.Controllers
{

    [Route("api/Orders")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public OrderController(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("GetOrders")]
        public List<OrderDto> GetOrders()
        {
            var orders = _context.Orders.ToList();
            var orderDtos = _mapper.Map<List<OrderDto>>(orders);
            return orderDtos;
        }

        [Authorize]
        [HttpGet("GetOrder/{id}")]
        public OrderDto GetOrder(int id)
        {
            var order = _context.Orders.FirstOrDefault(o => o.Id == id);

            if (order == null)
            {
                return null;
            }

            var orderDto = _mapper.Map<OrderDto>(order);
            return orderDto;
        }

        [Authorize]
        [HttpPost("CreateOrder")]
        public ResultDto CreateOrder(OrderDto dto)
        {
            var result = new ResultDto();

            if (dto == null)
            {
                result.Status = false;
                result.Message = "Geçersiz veri.";
                return result;
            }

            var order = _mapper.Map<Order>(dto);
            _context.Orders.Add(order);
            _context.SaveChanges();

            result.Status = true;
            result.Message = "Sipariş oluşturuldu.";
            return result;
        }

        [Authorize]
        [HttpPut("UpdateOrder/{id}")]
        public ResultDto UpdateOrder(int id, OrderDto dto)
        {
            var result = new ResultDto();

            if (id != dto.Id)
            {
                result.Status = false;
                result.Message = "İstek gövdesi ve id uyuşmuyor.";
                return result;
            }

            var orderToUpdate = _context.Orders.FirstOrDefault(o => o.Id == id);
            if (orderToUpdate == null)
            {
                result.Status = false;
                result.Message = "Sipariş bulunamadı.";
                return result;
            }

            _mapper.Map(dto, orderToUpdate);
            _context.SaveChanges();

            result.Status = true;
            result.Message = "Sipariş güncellendi.";
            return result;
        }

        [Authorize]
        [HttpDelete("DeleteOrder/{id}")]
        public ResultDto DeleteOrder(int id)
        {
            var result = new ResultDto();

            var orderToDelete = _context.Orders.FirstOrDefault(o => o.Id == id);
            if (orderToDelete == null)
            {
                result.Status = false;
                result.Message = "Sipariş bulunamadı.";
                return result;
            }

            _context.Orders.Remove(orderToDelete);
            _context.SaveChanges();

            result.Status = true;
            result.Message = "Sipariş silindi.";
            return result;
        }
    }
}