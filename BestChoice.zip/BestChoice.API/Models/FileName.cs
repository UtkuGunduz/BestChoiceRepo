﻿namespace BestChoice.API.Models
{
    public class FileName
    {
    }
}
