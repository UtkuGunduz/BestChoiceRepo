﻿namespace BestChoice.API.Models
{
    public class Stock
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public int? Quantity { get; set; }
    }
}
