﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BestChoice.API.Migrations
{
    /// <inheritdoc />
    public partial class IdentityOK : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
