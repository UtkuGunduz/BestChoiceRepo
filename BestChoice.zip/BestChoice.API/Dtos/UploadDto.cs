﻿namespace BestChoice.API.Dtos
{
    public class UploadDto
    {
        public string PicData { get; set; }
        public string PicExt { get; set; }
        public string UserId { get; set; }
    }
}
