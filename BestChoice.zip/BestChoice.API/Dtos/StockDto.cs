﻿namespace BestChoice.API.Dtos
{
    public class StockDto
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public int? Quantity { get; set; }
    }
}
